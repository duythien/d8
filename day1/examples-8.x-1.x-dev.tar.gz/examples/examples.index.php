<?php

/**
 * @file
 * Example modules
 * Add links here as they are ported to 8.x-1.x
 *
 * - @link block_example.module Defining blocks @endlink
 * - @link cron_example.module Cron related examples @endlink
 * - @link dbtng_example.module Database examples (DBTNG) @endlink
 * - @link page_example.module Creating a custom page @endlink
 */
