(function($){$(function() { $("#accordion").accordion(); })})(jQuery);
